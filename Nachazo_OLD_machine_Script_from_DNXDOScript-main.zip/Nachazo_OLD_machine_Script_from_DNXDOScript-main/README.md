# Nachazo_OLD_machine_Script_from_DNXDOScript
 Script for Old machines based on deen0x one.
